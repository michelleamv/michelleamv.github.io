---
title: 'Examen'
date: 2020-06-17T19:30:08+10:00
draft: false
weight: 4
summary: Trabajo realizado en base a la marca de maceteros P-Plants
---

![P1](/fb3/img/examen/a.png)

# Nuestros Referentes
![P1](/fb3/img/examen/b.png)

# Manual de Uso
![P1](/fb3/img/examen/c.png)

# Guía de Fabricación
![P1](/fb3/img/examen/d.png)

# Planimetrías

## Molde
![P1](/fb3/img/examen/e.png)

## Contenedor
![P1](/fb3/img/examen/f.png)

## Contramolde
![P1](/fb3/img/examen/g.png)

## Isométrica 
![P1](/fb3/img/examen/h.png)

# Isométrica Explotada
![P1](/fb3/img/examen/i.png)

# Fotomontajes
![P1](/fb3/img/examen/j.png)

![P1](/fb3/img/examen/k.png)

![P1](/fb3/img/examen/l.png)

# Macetero en uso
![P1](/fb3/img/examen/m.png)



{{< gallery dir="/img/examen/" />}} {{< load-photoswipe >}}
